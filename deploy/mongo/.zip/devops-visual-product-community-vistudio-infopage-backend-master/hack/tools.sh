#!/bin/bash

PROJECT_HOME=$(
	cd "$(dirname "${BASH_SOURCE[0]}")" &&
		cd .. &&
		pwd
)

source "${PROJECT_HOME}/hack/util.sh"

LINTER_CONFIG=${PROJECT_HOME}/.golangci.yml


all_modules=$(util::find_modules)

# functions
# lint all mod
function lint() {
  fail=0
	for mod in $all_modules; do
		pushd "$mod" >/dev/null &&
			echo "golangci lint $mod"
			out=$(eval "golangci-lint run --timeout=5m --config=${LINTER_CONFIG}")
			if [[ "$out" != "" ]]; then
				echo "$out"
				fail=1
			fi
		popd >/dev/null || exit
	done
	if [[ $fail -eq 1 ]]; then
	  exit 1
	fi
}

# try to fix all mod with golangci-lint
function fix() {
	for mod in $all_modules; do
		local in_failing
		util::array_contains "$mod" "${failing_modules[*]}" && in_failing=$? || in_failing=$?
		if [[ "$in_failing" -ne "0" ]]; then
			pushd "$mod" >/dev/null &&
				echo "golangci fix $mod" &&
				eval "golangci-lint run -v --fix --timeout=5m --config=${LINTER_CONFIG}"
			popd >/dev/null || exit
		fi
	done
}

case $1 in
lint)
	lint
	;;
fix)
	fix
	;;
esac