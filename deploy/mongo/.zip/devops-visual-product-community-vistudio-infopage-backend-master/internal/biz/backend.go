package biz

import (
	"context"

	v1 "vistudio-infopage-backend/internal/errors/v1"

	"github.com/go-kratos/kratos/v2/errors"
	"github.com/go-kratos/kratos/v2/log"
)

var (
	// ErrUserNotFound is user not found.
	ErrUserNotFound = errors.NotFound(v1.ErrorReason_USER_NOT_FOUND.String(), "user not found")
)

// Backend is a Backend model.
type Backend struct {
	Hello string
}

// BackendRepo is a Greater repo.
type BackendRepo interface {
	Save(context.Context, *Backend) (*Backend, error)
	Update(context.Context, *Backend) (*Backend, error)
	FindByID(context.Context, int64) (*Backend, error)
	ListByHello(context.Context, string) ([]*Backend, error)
	ListAll(context.Context) ([]*Backend, error)
}

// BackendUsecase is a Backend usecase.
type BackendUsecase struct {
	repo BackendRepo
	log  *log.Helper
}

// NewBackendUsecase new a Backend usecase.
func NewBackendUsecase(repo BackendRepo, logger log.Logger) *BackendUsecase {
	return &BackendUsecase{repo: repo, log: log.NewHelper(logger)}
}

// CreateBackend creates a Backend, and returns the new Backend.
func (uc *BackendUsecase) CreateBackend(ctx context.Context, g *Backend) (*Backend, error) {
	uc.log.WithContext(ctx).Infof("CreateBackend: %v", g.Hello)
	return uc.repo.Save(ctx, g)
}
