package biz

import (
	"context"
	"mime/multipart"
	"time"

	"github.com/google/wire"
)

// ProviderSet is biz providers.
var ProviderSet = wire.NewSet(NewBackendUsecase, NewFeedbackUsecase, NewUserUseCase, NewVideoUsecase)

type File struct {
	Path string
}

type Feedback struct {
	Types      string
	Version    string
	Title      string
	Content    string
	Connection string
	Product    string
	FileParts  []*multipart.FileHeader
}

type InternalUser struct {
	ID    string
	Name  string
	Token string
}

type OuterUser struct {
	ID    string
	Name  string
	Token string
	Phone string
	Mail  string
}

type Video struct {
	ID                     string
	Type                   string                `json:"type,omitempty"`
	Title                  string                `json:"title,omitempty"`
	Description            string                `json:"description,omitempty"`
	Tags                   []string              `json:"tags,omitempty"`
	VideoFilePart          *multipart.FileHeader `json:"videoFilePart,omitempty"`
	FrontCoverFilePart     *multipart.FileHeader `json:"frontCoverFilePart,omitempty"`
	UpdateTime             *time.Time            `json:"updateTime"`
	VideoRelativePath      *string               `json:"videoRelativePath"`
	FrontCoverRelativePath *string               `json:"frontCoverRelativePath"`
}

type Transaction interface {
	ExecTx(context.Context, func(ctx context.Context) error) error
}

type FileRepo interface {
	SaveLocalFile(relativePath string, file *multipart.FileHeader) error
}

type NotificationRepo interface {
	WeComGroupRobot(ctx context.Context, feedback *Feedback, files []*File) error
}

type OuterUserRepo interface {
	// VerifyTicket 验证ticket
	VerifyTicket(ctx context.Context, ticket string) (*OuterUser, error)
	// Sign 生成 Token
	Sign(ctx context.Context, outerUser *OuterUser) (*OuterUser, error)
}

type InternalUserRepo interface {
	// VerifyTicket 验证ticket
	VerifyTicket(ctx context.Context, ticket string) (*InternalUser, error)
	// Sign 生成 Token
	Sign(ctx context.Context, username string) (*InternalUser, error)
}

type FeedbackRepo interface {
	// Save 保存反馈记录
	Save(ctx context.Context, feedback *Feedback, files []*File) error
}

type VideoRepo interface {
	// Save 保存视频记录
	Save(ctx context.Context, video *Video) error
	// Exists 判断视频是否存在
	Exists(ctx context.Context, videoID string) (*Video, bool, error)
	// Update 更新视频记录
	Update(ctx context.Context, video *Video) error
	// ListByType 按类型返回视频列表
	ListByType(ctx context.Context, videoType string) ([]*Video, error)
	// DeleteOne 删除一个视频
	DeleteOne(ctx context.Context, videoID string) error
	// ListTagsByType 按类型返回视频标签列表
	ListTagsByType(ctx context.Context, videoType string) ([]string, error)
}
