/******************************************************************************
* FILENAME:      feedback.go
*
* AUTHORS:       Xie Rongwang START DATE: 周六 11月 19 2022
*
* LAST MODIFIED: 星期六, 十一月 19th 2022, 上午9:46
*
* CONTACT:       rongwang.xie@smartmore.com
******************************************************************************/

package biz

import (
	"context"
	"fmt"
	"mime/multipart"
	"path"
	"sync"
	"vistudio-infopage-backend/internal/conf"

	"github.com/go-kratos/kratos/v2/errors"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/google/uuid"
)

type FeedbackUsecase struct {
	file         FileRepo
	notify       NotificationRepo
	feedbackRepo FeedbackRepo
	conf         *conf.Data

	log *log.Helper
}

func (f *FeedbackUsecase) Feedback(ctx context.Context, feedback *Feedback) error {
	wg, fileIOBuf, fileDBBuf, fileErrsBuf := f.saveLocalFile(10)

	for _, file := range feedback.FileParts {
		fileIOBuf <- file
	}
	close(fileIOBuf)
	wg.Wait()
	close(fileDBBuf)
	close(fileErrsBuf)

	for fileErr := range fileErrsBuf {
		return errors.New(500, fmt.Sprintf("上传文件:%v出错", fileErr), fmt.Sprintf("files: %v upload failed", fileErr))
	}

	files := make([]*File, 0, len(feedback.FileParts))
	for file := range fileDBBuf {
		files = append(files, file)
	}

	err := f.feedbackRepo.Save(ctx, feedback, files)
	if err != nil {
		return err
	}

	return f.notify.WeComGroupRobot(ctx, feedback, files)
}

func (f *FeedbackUsecase) saveLocalFile(bufSize int) (
	wg *sync.WaitGroup,
	fileIOBuf chan *multipart.FileHeader,
	fileDBBuf chan *File,
	fileErrsBuf chan string,
) {
	wg = &sync.WaitGroup{}
	fileIOBuf = make(chan *multipart.FileHeader, bufSize)
	fileDBBuf = make(chan *File, bufSize)
	fileErrsBuf = make(chan string, bufSize)

	for i := 0; i < bufSize; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for file := range fileIOBuf {
				if file == nil {
					return
				}
				intermediatePath := uuid.New().String()
				relativePath := path.Join(f.conf.File.FeedbackPath, intermediatePath, file.Filename)
				saveErr := f.file.SaveLocalFile(relativePath, file)
				if saveErr != nil {
					fileErrsBuf <- fmt.Sprintf(file.Filename+"(%s)", saveErr.Error())
					f.log.Infof("save file %s error: %v", file.Filename, saveErr)
					continue
				}
				fileDBBuf <- &File{Path: relativePath}
			}
		}()
	}
	return wg, fileIOBuf, fileDBBuf, fileErrsBuf
}

func NewFeedbackUsecase(file FileRepo, notify NotificationRepo, feedbackRepo FeedbackRepo,
	conf *conf.Data, logger log.Logger) *FeedbackUsecase {
	return &FeedbackUsecase{
		file:         file,
		notify:       notify,
		feedbackRepo: feedbackRepo,
		conf:         conf,
		log:          log.NewHelper(log.With(logger, "module", "biz/feedback")),
	}
}
