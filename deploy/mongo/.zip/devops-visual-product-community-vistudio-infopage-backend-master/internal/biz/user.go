/******************************************************************************
* FILENAME:      user.go
*
* AUTHORS:       Xie Rongwang START DATE: 周四 12月 08 2022
*
* LAST MODIFIED: 星期四, 十二月 08th 2022, 下午4:05
*
* CONTACT:       rongwang.xie@smartmore.com
******************************************************************************/

package biz

import (
	"context"

	"github.com/go-kratos/kratos/v2/log"
)

type UserUsecase struct {
	outerUserRepo    OuterUserRepo
	internalUserRepo InternalUserRepo
	tm               Transaction
	log              *log.Helper
}

func NewUserUseCase(outerUserRepo OuterUserRepo, internalUserRepo InternalUserRepo, tm Transaction, logger log.Logger) *UserUsecase {
	return &UserUsecase{
		outerUserRepo:    outerUserRepo,
		internalUserRepo: internalUserRepo,
		tm:               tm,
		log:              log.NewHelper(log.With(logger, "module", "backend/biz/user")),
	}
}

// InternalVerifyTicket 内部用户单点登录Ticket验证
func (u *UserUsecase) InternalVerifyTicket(ctx context.Context, ticket string) (*InternalUser, error) {
	user, err := u.internalUserRepo.VerifyTicket(ctx, ticket)
	if err != nil {
		return nil, err
	}
	if err = u.tm.ExecTx(ctx, func(ctx context.Context) error {
		user, err = u.internalUserRepo.Sign(ctx, user.Name)
		if err != nil {
			return err
		}
		return err
	}); err != nil {
		return nil, err
	}
	return user, nil
}

// OuterVerifyTicket 外部用户单点登录Ticket验证
func (u *UserUsecase) OuterVerifyTicket(ctx context.Context, ticket string) (*OuterUser, error) {
	user, err := u.outerUserRepo.VerifyTicket(ctx, ticket)
	if err != nil {
		return nil, err
	}
	if err = u.tm.ExecTx(ctx, func(ctx context.Context) error {
		user, err = u.outerUserRepo.Sign(ctx, user)
		if err != nil {
			return err
		}
		return err
	}); err != nil {
		return nil, err
	}
	return user, nil
}
