/******************************************************************************
* FILENAME:      video.go
*
* AUTHORS:       Xie Rongwang START DATE: 周三 12月 14 2022
*
* LAST MODIFIED: 星期三, 十二月 14th 2022, 下午3:36
*
* CONTACT:       rongwang.xie@smartmore.com
******************************************************************************/

package biz

import (
	"context"
	"path"

	"github.com/go-kratos/kratos/v2/errors"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/google/uuid"

	"vistudio-infopage-backend/internal/conf"
)

type VideoUsecase struct {
	file  FileRepo
	video VideoRepo
	conf  *conf.Data
	tm    Transaction

	log *log.Helper
}

func (v *VideoUsecase) CreateVideo(ctx context.Context, video *Video) error {
	intermediatePath := uuid.New().String()
	videoRelativePath := path.Join(v.conf.File.VideoPath, intermediatePath, video.VideoFilePart.Filename)
	// 单个视频文件，串行上传
	err := v.file.SaveLocalFile(videoRelativePath, video.VideoFilePart)
	if err != nil {
		return err
	}
	frontCoverRelativePath := path.Join(v.conf.File.FrontCoverPath, intermediatePath, video.FrontCoverFilePart.Filename)
	// 单个图片文件，串行上传
	err = v.file.SaveLocalFile(frontCoverRelativePath, video.FrontCoverFilePart)
	if err != nil {
		return err
	}
	video.VideoRelativePath = &videoRelativePath
	video.FrontCoverRelativePath = &frontCoverRelativePath
	return v.video.Save(ctx, video)
}

func (v *VideoUsecase) UpdateVideo(ctx context.Context, video *Video) error {
	return v.tm.ExecTx(ctx, func(ctx context.Context) error {
		exist, ok, err := v.video.Exists(ctx, video.ID)
		if err != nil {
			return err
		}
		if !ok {
			return errors.New(500, "video not exists", "视频不存在")
		}
		video.VideoRelativePath = exist.VideoRelativePath
		video.FrontCoverRelativePath = exist.FrontCoverRelativePath

		intermediatePath := uuid.New().String()
		if video.VideoFilePart != nil {
			videoRelativePath := path.Join(v.conf.File.VideoPath, intermediatePath, video.VideoFilePart.Filename)
			// 单个视频文件，串行上传
			err = v.file.SaveLocalFile(videoRelativePath, video.VideoFilePart)
			if err != nil {
				return err
			}
			video.VideoRelativePath = &videoRelativePath
		}
		if video.FrontCoverFilePart != nil {
			frontCoverRelativePath := path.Join(v.conf.File.FrontCoverPath, intermediatePath, video.FrontCoverFilePart.Filename)
			// 单个图片文件，串行上传
			err = v.file.SaveLocalFile(frontCoverRelativePath, video.FrontCoverFilePart)
			if err != nil {
				return err
			}
			video.FrontCoverRelativePath = &frontCoverRelativePath
		}
		return v.video.Update(ctx, video)
	})
}

// ListByType 按类型返回视频列表
func (v *VideoUsecase) ListByType(ctx context.Context, videoType string) ([]*Video, error) {
	return v.video.ListByType(ctx, videoType)
}

// DeleteOne 删除一个视频
func (v *VideoUsecase) DeleteOne(ctx context.Context, videoID string) error {
	return v.video.DeleteOne(ctx, videoID)
}

// ListTagsByType 按类型返回视频标签列表
func (v *VideoUsecase) ListTagsByType(ctx context.Context, videoType string) ([]string, error) {
	return v.video.ListTagsByType(ctx, videoType)
}

func NewVideoUsecase(file FileRepo, video VideoRepo, conf *conf.Data, tm Transaction, logger log.Logger) *VideoUsecase {
	return &VideoUsecase{
		file:  file,
		video: video,
		conf:  conf,
		tm:    tm,
		log:   log.NewHelper(log.With(logger, "module", "biz/video")),
	}
}
