package data

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"time"

	"e.coding.smoa.cloud/devops/fortress/fortress-client"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/google/wire"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"go.mongodb.org/mongo-driver/mongo/readpref"

	"vistudio-infopage-backend/internal/biz"
	"vistudio-infopage-backend/internal/conf"
	"vistudio-infopage-backend/internal/pkg/token"
)

// ProviderSet is data providers.
var ProviderSet = wire.NewSet(NewData, NewWeComClient, NewMongoDBClient, NewTransaction,
	NewBackendRepo, NewNotificationRepo, NewFileRepo, NewInternalUserRepo, NewOuterUserRepo,
	NewFeedbackRepo, NewVideoRepo, token.NewSigner)

const (
	MaxIdleConns               = 100
	DefaultMaxIdleConnsPerHost = 100
)

// Data .
type Data struct {
	client   *http.Client
	fortress fortress.Client
	signer   token.Signer
	db       *mongo.Database
}

func (d *Data) ExecTx(ctx context.Context, f func(ctx context.Context) error) error {
	session, err := d.db.Client().StartSession()
	if err != nil {
		return err
	}
	defer session.EndSession(ctx)
	_, err = session.WithTransaction(ctx, func(ctx mongo.SessionContext) (interface{}, error) {
		return nil, f(ctx)
	})
	return err
}

// NewData .
func NewData(client *http.Client, db *mongo.Database, signer token.Signer, logger log.Logger) (*Data, func(), error) {
	cleanup := func() {
		if err := db.Client().Disconnect(context.TODO()); err != nil {
			log.NewHelper(logger).Error(err)
		}
		log.NewHelper(logger).Info("closing the data resources")
	}
	return &Data{
		client:   client,
		fortress: fortress.NewFortressClient(),
		signer:   signer,
		db:       db,
	}, cleanup, nil
}

func NewWeComClient() *http.Client {
	return &http.Client{
		Transport: &http.Transport{
			Proxy: http.ProxyFromEnvironment,
			DialContext: (&net.Dialer{
				Timeout:   30 * time.Second,
				KeepAlive: 30 * time.Second,
			}).DialContext,
			MaxIdleConns:        MaxIdleConns,
			MaxIdleConnsPerHost: DefaultMaxIdleConnsPerHost,
			IdleConnTimeout:     1 * time.Second,
		},
	}
}

func NewMongoDBClient(c *conf.Data) *mongo.Database {
	endpoint := fmt.Sprintf("mongodb://%s:%s@%s", c.Database.Username, c.Database.Password, c.Database.Source)
	// Connect to MongoDB
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	client, err := mongo.Connect(
		ctx,
		options.Client().ApplyURI(endpoint).SetReplicaSet(c.Database.ReplicaSet).SetReadPreference(readpref.Primary()),
	)
	if err != nil {
		log.Error(err)
		panic(err)
	}
	// Check the connection
	if err = client.Ping(ctx, nil); err != nil {
		log.Error(err)
		panic(err)
	}
	return client.Database(c.Database.Database)
}

func NewTransaction(d *Data) biz.Transaction {
	return d
}
