/******************************************************************************
* FILENAME:      feedback.go
*
* AUTHORS:       Xie Rongwang START DATE: 周三 12月 14 2022
*
* LAST MODIFIED: 星期三, 十二月 14th 2022, 下午2:38
*
* CONTACT:       rongwang.xie@smartmore.com
******************************************************************************/

package data

import (
	"context"

	"github.com/go-kratos/kratos/v2/log"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"

	"vistudio-infopage-backend/internal/biz"
)

const feedbackCollection = "feedback"

type Feedback struct {
	ID         primitive.ObjectID `bson:"_id"`
	Types      string             `bson:"types,omitempty"`
	Version    string             `bson:"version,omitempty"`
	Title      string             `bson:"title,omitempty"`
	Content    string             `bson:"content,omitempty"`
	Connection string             `bson:"connection,omitempty"`
	Product    string             `bson:"product,omitempty"`
	FilePaths  []string           `bson:"filePaths,omitempty"`
}

type feedbackRepo struct {
	data       *Data
	collection *mongo.Collection
	log        *log.Helper
}

func (f *feedbackRepo) Save(ctx context.Context, feedback *biz.Feedback, files []*biz.File) error {
	filePaths := make([]string, 0, len(files))
	for _, file := range files {
		filePaths = append(filePaths, file.Path)
	}
	doc := &Feedback{
		ID:         primitive.NewObjectID(),
		Types:      feedback.Types,
		Version:    feedback.Version,
		Title:      feedback.Title,
		Content:    feedback.Content,
		Connection: feedback.Connection,
		Product:    feedback.Product,
		FilePaths:  filePaths,
	}
	_, err := f.collection.InsertOne(ctx, doc)
	return err
}

func NewFeedbackRepo(data *Data, logger log.Logger) biz.FeedbackRepo {
	return &feedbackRepo{
		data:       data,
		collection: data.db.Collection(feedbackCollection),
		log:        log.NewHelper(log.With(logger, "module", "data/feedbackRepo")),
	}
}
