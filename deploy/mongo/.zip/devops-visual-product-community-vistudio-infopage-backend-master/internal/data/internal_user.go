/******************************************************************************
* FILENAME:      internal_user.go
*
* AUTHORS:       Xie Rongwang START DATE: 周四 12月 08 2022
*
* LAST MODIFIED: 星期四, 十二月 08th 2022, 下午5:21
*
* CONTACT:       rongwang.xie@smartmore.com
******************************************************************************/

package data

import (
	"context"

	"github.com/go-kratos/kratos/v2/log"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"

	"vistudio-infopage-backend/internal/biz"
	"vistudio-infopage-backend/internal/conf"
	errorpb "vistudio-infopage-backend/internal/errors/v1"
	"vistudio-infopage-backend/internal/pkg/token"
)

const internalUserCollection = "internalUser"

type InternalUser struct {
	ID   primitive.ObjectID `bson:"_id"`
	Name string             `bson:"name,omitempty"`
}

type internalUserRepo struct {
	data       *Data
	collection *mongo.Collection
	dataAuth   *conf.Data_Auth
	log        *log.Helper
}

// VerifyTicket 验证ticket
func (i *internalUserRepo) VerifyTicket(ctx context.Context, ticket string) (*biz.InternalUser, error) {
	verifyTicket, err := i.data.fortress.VerifyTicket(ticket, i.dataAuth.Fortress.Appid, i.dataAuth.Fortress.Appsecret)
	if err != nil {
		return nil, errorpb.ErrorTicketError(err.Error())
	}
	i.log.Infof("username: %s", verifyTicket.Username)
	return &biz.InternalUser{Name: verifyTicket.Username}, nil
}

// Sign 生成 Token
func (i *internalUserRepo) Sign(ctx context.Context, username string) (*biz.InternalUser, error) {
	user := &InternalUser{}
	if err := i.collection.FindOne(ctx, bson.M{"name": username}).Decode(user); err != nil && err != mongo.ErrNoDocuments {
		return nil, err
	}
	user = &InternalUser{
		ID:   primitive.NewObjectID(),
		Name: username,
	}
	if _, err := i.collection.InsertOne(ctx, user); err != nil {
		return nil, err
	}

	tokenStr, err := i.data.signer.Sign(&token.User{
		ID:   user.ID.Hex(),
		Name: user.Name,
	})
	if err != nil {
		return nil, err
	}
	return &biz.InternalUser{Token: tokenStr, ID: user.ID.Hex(), Name: username}, err
}

func NewInternalUserRepo(data *Data, conf *conf.Data, logger log.Logger) biz.InternalUserRepo {
	return &internalUserRepo{
		data:       data,
		collection: data.db.Collection(internalUserCollection),
		dataAuth:   conf.Auth,
		log:        log.NewHelper(log.With(logger, "module", "data/internalUserRepo")),
	}
}
