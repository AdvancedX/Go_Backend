/******************************************************************************
* FILENAME:      notification.go
*
* AUTHORS:       Xie Rongwang START DATE: 周六 11月 19 2022
*
* LAST MODIFIED: 星期六, 十一月 19th 2022, 下午2:57
*
* CONTACT:       rongwang.xie@smartmore.com
******************************************************************************/

package data

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"path"

	"github.com/go-kratos/kratos/v2/log"

	"vistudio-infopage-backend/internal/biz"
	"vistudio-infopage-backend/internal/conf"
)

const (
	messageTemplate = `<font color="info">**实时新增用户反馈，请相关同事注意。**</font>


**产品: **<font color="comment">%s</font>
**类型: **<font color="comment">%s</font>
**标题: **<font color="comment">%s</font>
**内容: **<font color="comment">%s</font>
**版本号: **<font color="comment">%s</font>
**联系方式: **<font color="comment">%s</font>


**附件(内网下载): **`
)

type WeComGroupRobotRequest struct {
	Msgtype  string    `json:"msgtype"`
	Markdown *Markdown `json:"markdown"`
}

type Markdown struct {
	Content string `json:"content"`
}

type notificationRepo struct {
	data *Data
	conf *conf.Data

	log *log.Helper
}

func (n *notificationRepo) WeComGroupRobot(ctx context.Context, feedback *biz.Feedback, files []*biz.File) error {
	message := fmt.Sprintf(messageTemplate, feedback.Product, feedback.Types, feedback.Title,
		feedback.Content, feedback.Version, feedback.Connection)
	if len(files) == 0 {
		message += "无"
	} else {
		for _, file := range files {
			_, filename := path.Split(file.Path)
			download := n.conf.Frontend.Addr + path.Join(n.conf.Frontend.DownloadPath, file.Path)
			message += fmt.Sprintf("\n> [%s](%s)", filename, download)
		}
	}
	requestBody := WeComGroupRobotRequest{
		Msgtype:  "markdown",
		Markdown: &Markdown{Content: message},
	}
	body, err := json.Marshal(requestBody)
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, n.conf.Robot.MessageURL, bytes.NewBuffer(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	response, err := n.data.client.Do(req)
	if err != nil || response.StatusCode != http.StatusOK {
		return err
	}
	return nil
}

func NewNotificationRepo(data *Data, conf *conf.Data, logger log.Logger) biz.NotificationRepo {
	return &notificationRepo{
		data: data,
		conf: conf,
		log:  log.NewHelper(log.With(logger, "module", "data/notification")),
	}
}
