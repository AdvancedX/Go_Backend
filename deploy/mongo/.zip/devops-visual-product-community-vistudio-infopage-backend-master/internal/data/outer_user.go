/******************************************************************************
* FILENAME:      internal_user.go
*
* AUTHORS:       Xie Rongwang START DATE: 周四 12月 08 2022
*
* LAST MODIFIED: 星期四, 十二月 08th 2022, 下午5:21
*
* CONTACT:       rongwang.xie@smartmore.com
******************************************************************************/

package data

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"

	"github.com/go-kratos/kratos/v2/log"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"

	"vistudio-infopage-backend/internal/biz"
	"vistudio-infopage-backend/internal/conf"
	"vistudio-infopage-backend/internal/pkg/token"
)

const outerUserCollection = "outerUser"

type OuterUser struct {
	ID    primitive.ObjectID `bson:"_id"`
	Name  string             `bson:"name,omitempty"`
	Phone string             `bson:"phone,omitempty"`
	Mail  string             `bson:"mail,omitempty"`
}

type VerifyRequest struct {
	CTicket   string `json:"cTicket"`
	AppSecret string `json:"appSecret"`
}

type VerifyReply struct {
	UserName string `json:"userName,omitempty"`
	Phone    string `json:"phone,omitempty"`
	Mail     string `json:"mail,omitempty"`
}

type outerUserRepo struct {
	data       *Data
	collection *mongo.Collection
	dataAuth   *conf.Data_Auth
	log        *log.Helper
}

// VerifyTicket 验证ticket
func (i *outerUserRepo) VerifyTicket(ctx context.Context, ticket string) (*biz.OuterUser, error) {
	reqBody := VerifyRequest{
		CTicket:   ticket,
		AppSecret: i.dataAuth.FortressCiam.Appsecret,
	}
	body, err := json.Marshal(&reqBody)
	if err != nil {
		return nil, err
	}
	addr := i.dataAuth.FortressCiam.Addr + i.dataAuth.FortressCiam.VerifyApi
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, addr, bytes.NewBuffer(body))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	response, err := i.data.client.Do(req)
	if err != nil {
		return nil, err
	}
	if response.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("验证ticket请求失败：%d", response.StatusCode)
	}
	defer response.Body.Close()
	var resp VerifyReply
	data, err := ioutil.ReadAll(response.Body)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(data, &resp)
	if err != nil {
		return nil, err
	}

	i.log.Infof("username: %s", resp.UserName)
	return &biz.OuterUser{Name: resp.UserName, Phone: resp.Phone, Mail: resp.Mail}, nil
}

// Sign 生成 Token
func (i *outerUserRepo) Sign(ctx context.Context, outerUser *biz.OuterUser) (*biz.OuterUser, error) {
	user := &OuterUser{}
	if err := i.collection.FindOne(ctx, bson.M{"name": outerUser.Name}).Decode(user); err != nil && err != mongo.ErrNoDocuments {
		return nil, err
	}
	user = &OuterUser{
		ID:    primitive.NewObjectID(),
		Name:  outerUser.Name,
		Phone: outerUser.Phone,
		Mail:  outerUser.Mail,
	}
	if _, err := i.collection.InsertOne(ctx, user); err != nil {
		return nil, err
	}

	tokenStr, err := i.data.signer.Sign(&token.User{
		ID:   user.ID.Hex(),
		Name: user.Name,
	})
	if err != nil {
		return nil, err
	}
	return &biz.OuterUser{
		Token: tokenStr,
		ID:    user.ID.Hex(),
		Name:  user.Name,
		Phone: user.Phone,
		Mail:  user.Mail,
	}, err
}

func NewOuterUserRepo(data *Data, conf *conf.Data, logger log.Logger) biz.OuterUserRepo {
	return &outerUserRepo{
		data:       data,
		collection: data.db.Collection(outerUserCollection),
		dataAuth:   conf.Auth,
		log:        log.NewHelper(log.With(logger, "module", "data/outerUserRepo")),
	}
}
