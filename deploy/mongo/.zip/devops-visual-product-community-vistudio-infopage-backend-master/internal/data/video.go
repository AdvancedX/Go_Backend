/******************************************************************************
* FILENAME:      video.go
*
* AUTHORS:       Xie Rongwang START DATE: 周三 12月 14 2022
*
* LAST MODIFIED: 星期三, 十二月 14th 2022, 下午4:22
*
* CONTACT:       rongwang.xie@smartmore.com
******************************************************************************/

package data

import (
	"context"
	"time"

	"github.com/go-kratos/kratos/v2/log"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"

	"vistudio-infopage-backend/internal/biz"
	"vistudio-infopage-backend/internal/pkg/utils"
)

const videoCollection = "video"

type Video struct {
	ID                     primitive.ObjectID `bson:"_id"`
	Type                   string             `bson:"type,omitempty"`
	Title                  string             `bson:"title,omitempty"`
	Description            string             `bson:"description,omitempty"`
	Tags                   []string           `bson:"tags,omitempty"`
	UpdateTime             *time.Time         `bson:"updateTime"`
	VideoRelativePath      *string            `bson:"videoRelativePath"`
	FrontCoverRelativePath *string            `bson:"frontCoverRelativePath"`
}

type videoRepo struct {
	data       *Data
	collection *mongo.Collection
	log        *log.Helper
}

// Save 保存视频记录
func (v *videoRepo) Save(ctx context.Context, video *biz.Video) error {
	now := time.Now()
	doc := &Video{
		ID:                     primitive.NewObjectID(),
		Type:                   video.Type,
		Title:                  video.Title,
		Description:            video.Description,
		Tags:                   video.Tags,
		UpdateTime:             &now,
		VideoRelativePath:      video.VideoRelativePath,
		FrontCoverRelativePath: video.FrontCoverRelativePath,
	}
	_, err := v.collection.InsertOne(ctx, doc)
	return err
}

// Exists 判断视频是否存在
func (v *videoRepo) Exists(ctx context.Context, videoID string) (*biz.Video, bool, error) {
	video := &Video{}
	objectID, err := primitive.ObjectIDFromHex(videoID)
	if err != nil {
		return nil, false, err
	}
	err = v.collection.FindOne(ctx, bson.M{"_id": objectID}).Decode(video)
	if err != nil {
		return nil, false, err
	}
	return &biz.Video{
		ID:                     video.ID.Hex(),
		Type:                   video.Type,
		Title:                  video.Title,
		Description:            video.Description,
		Tags:                   video.Tags,
		VideoFilePart:          nil,
		FrontCoverFilePart:     nil,
		UpdateTime:             video.UpdateTime,
		VideoRelativePath:      video.VideoRelativePath,
		FrontCoverRelativePath: video.FrontCoverRelativePath,
	}, !video.ID.IsZero(), nil
}

// Update 更新视频记录
func (v *videoRepo) Update(ctx context.Context, video *biz.Video) error {
	now := time.Now()
	hex, err := primitive.ObjectIDFromHex(video.ID)
	if err != nil {
		return err
	}
	doc := &Video{
		ID:                     hex,
		Type:                   video.Type,
		Title:                  video.Title,
		Description:            video.Description,
		Tags:                   video.Tags,
		UpdateTime:             &now,
		VideoRelativePath:      video.VideoRelativePath,
		FrontCoverRelativePath: video.FrontCoverRelativePath,
	}
	_, err = v.collection.UpdateByID(ctx, hex, bson.D{{Key: "$set", Value: doc}})
	return err
}

// ListByType 按类型返回视频列表
func (v *videoRepo) ListByType(ctx context.Context, videoType string) ([]*biz.Video, error) {
	opts := options.Find().SetSort(bson.D{{Key: "updateTime", Value: -1}})
	cursor, err := v.collection.Find(ctx, bson.M{"type": videoType}, opts)
	if err != nil {
		return nil, err
	}
	var videos []*Video
	err = cursor.All(ctx, &videos)
	if err != nil {
		return nil, err
	}
	bizVideos := make([]*biz.Video, 0, len(videos))
	for _, video := range videos {
		bizVideos = append(bizVideos, &biz.Video{
			ID:                     video.ID.Hex(),
			Type:                   video.Type,
			Title:                  video.Title,
			Description:            video.Description,
			Tags:                   video.Tags,
			VideoFilePart:          nil,
			FrontCoverFilePart:     nil,
			UpdateTime:             video.UpdateTime,
			VideoRelativePath:      video.VideoRelativePath,
			FrontCoverRelativePath: video.FrontCoverRelativePath,
		})
	}
	return bizVideos, err
}

// DeleteOne 删除一个视频
func (v *videoRepo) DeleteOne(ctx context.Context, videoID string) error {
	idFromHex, err := primitive.ObjectIDFromHex(videoID)
	if err != nil {
		return err
	}
	_, err = v.collection.DeleteOne(ctx, bson.M{"_id": idFromHex})
	return err
}

// ListTagsByType 按类型返回视频标签列表
func (v *videoRepo) ListTagsByType(ctx context.Context, videoType string) ([]string, error) {
	opts := options.Find().SetSort(bson.D{{Key: "updateTime", Value: -1}})
	cursor, err := v.collection.Find(ctx, bson.M{"type": videoType}, opts)
	if err != nil {
		return nil, err
	}
	var videos []*Video
	err = cursor.All(ctx, &videos)
	if err != nil {
		return nil, err
	}
	var tags []string
	for _, video := range videos {
		for _, tag := range video.Tags {
			if !utils.SliceContainsAny(tags, tag) {
				tags = append(tags, tag)
			}
		}
	}
	return tags, err
}

func NewVideoRepo(data *Data, logger log.Logger) biz.VideoRepo {
	return &videoRepo{
		data:       data,
		collection: data.db.Collection(videoCollection),
		log:        log.NewHelper(log.With(logger, "module", "data/videoRepo")),
	}
}
