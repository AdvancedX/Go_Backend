/******************************************************************************
* FILENAME:      token.go
*
* AUTHORS:       Qiu Siyu START DATE: 周三 7月 13 2022
*
* LAST MODIFIED: 星期三, 七月 13th 2022, 上午10：40
*
* CONTACT:       siyu.qiu@smartmore.com
******************************************************************************/

package middleware

import (
	"context"
	"strings"

	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-kratos/kratos/v2/middleware"
	"github.com/go-kratos/kratos/v2/middleware/selector"
	"github.com/go-kratos/kratos/v2/transport"

	v1 "vistudio-infopage-backend/api/backend/v1"
	errorpb "vistudio-infopage-backend/internal/errors/v1"
	"vistudio-infopage-backend/internal/pkg/token"
	"vistudio-infopage-backend/internal/pkg/utils"
)

const OperationBackendCustomFeedback = "/vistudio.infopage.backend.backend.v1.Backend/custom/feedback"
const OperationBackendCustomCreateVideo = "/vistudio.infopage.backend.backend.v1.Backend/custom/createVideo"
const OperationBackendCustomUpdateVideo = "/vistudio.infopage.backend.backend.v1.Backend/custom/updateVideo"

var ignorePath = []string{
	// v1.OperationBackendDeleteVideo,
	v1.OperationBackendGetOuterToken,
	v1.OperationBackendGetToken,
	v1.OperationBackendHealthCheck,
	v1.OperationBackendListTagsByType,
	v1.OperationBackendListVideosByType,
	OperationBackendCustomFeedback,
	// OperationBackendCustomCreateVideo,
	// OperationBackendCustomUpdateVideo,
}

var rateLimitPath = []string{
	OperationBackendCustomFeedback,
}

// Token 用户验证Token校验器
func Token(signer token.Signer) middleware.Middleware {
	return func(handler middleware.Handler) middleware.Handler {
		return func(ctx context.Context, req interface{}) (reply interface{}, err error) {
			if _, ok := transport.FromServerContext(ctx); ok {
				// Do something on entering
				tokenString, err := utils.GetTokenFromContext(ctx)
				if err != nil {
					log.Error(errorpb.ErrorTokenNotExists("token不存在"))
					return nil, errorpb.ErrorTokenNotExists("token不存在")
				}
				claims, err := signer.Verify(tokenString)
				if err != nil {
					log.Error(err)
					return nil, err
				}
				ctx = context.WithValue(ctx, token.ClaimsContextKey{}, claims)
			}
			return handler(ctx, req)
		}
	}
}

// TokenIgnoreMatch Token校验器过滤路径
func TokenIgnoreMatch() selector.MatchFunc {
	return func(ctx context.Context, operation string) bool {
		for _, s := range ignorePath {
			if strings.EqualFold(operation, s) {
				return false
			}
		}
		return true
	}
}

// RateLimitMatch 限流器过滤路径
func RateLimitMatch() selector.MatchFunc {
	return func(ctx context.Context, operation string) bool {
		for _, s := range rateLimitPath {
			if strings.EqualFold(operation, s) {
				return true
			}
		}
		return false
	}
}
