/******************************************************************************
* FILENAME:      token.go
*
* AUTHORS:       Qiu Siyu START DATE: 周二 7月 12 2022
*
* LAST MODIFIED: 星期日, 七月 12th 2022, 下午16:12
*
* CONTACT:       siyu.qiu@smartmore.com
******************************************************************************/

package token

import (
	"context"
	"time"

	"github.com/golang-jwt/jwt/v4"
	"github.com/google/uuid"

	"vistudio-infopage-backend/internal/conf"
	errorpb "vistudio-infopage-backend/internal/errors/v1"
)

// Signer is an abstract interface for signing and verifying tokens
type Signer interface {
	Sign(audience *User) (string, error)
	Verify(token string) (*CustomizedClaims, error)
}

type (
	ClaimsContextKey struct{}
)

type defaultTokenSigner struct {
	tokenSigningKey  []byte
	accessExpiration time.Duration
}

type User struct {
	ID   string
	Name string
}

type CustomizedClaims struct {
	jwt.RegisteredClaims
	UserID string `json:"uid,omitempty"`
}

// NewSigner creates a default token signer
func NewSigner(conf *conf.Data) Signer {
	return &defaultTokenSigner{
		tokenSigningKey:  []byte(conf.Token.SignKey),
		accessExpiration: time.Duration(conf.Token.AccessExpiration) * time.Hour,
	}
}

func (tm *defaultTokenSigner) Sign(audience *User) (string, error) {
	token := jwt.NewWithClaims(jwt.SigningMethodHS256,
		CustomizedClaims{
			RegisteredClaims: jwt.RegisteredClaims{
				Audience:  []string{audience.Name},
				ExpiresAt: &jwt.NumericDate{Time: time.Now().Add(tm.accessExpiration)},
				ID:        uuid.New().String(),
				IssuedAt:  &jwt.NumericDate{Time: time.Now()},
				Issuer:    "",
				NotBefore: &jwt.NumericDate{Time: time.Now()},
				Subject:   "",
			},
			UserID: audience.ID,
		},
	)
	tok, err := token.SignedString(tm.tokenSigningKey)
	if err != nil {
		return "", errorpb.ErrorTokenSignError("token生成失败：%s", err.Error())
	}
	return tok, nil
}

// Verify extract username and error form token. The analysed username
// will be returned regardless of whether an error is encountered
func (tm *defaultTokenSigner) Verify(tokenString string) (*CustomizedClaims, error) {
	token, err := jwt.ParseWithClaims(
		tokenString,
		&CustomizedClaims{},
		func(t *jwt.Token) (interface{}, error) {
			if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, errorpb.ErrorInvalidToken("无效的token")
			}
			return tm.tokenSigningKey, nil
		},
	)
	if err != nil {
		ve, ok := err.(*jwt.ValidationError)
		if !ok {
			return nil, errorpb.ErrorInvalidToken("无效的token, err: [%s]", err)
		}
		if ve.Errors&jwt.ValidationErrorExpired != 0 {
			return nil, errorpb.ErrorTokenExpired("token过期, err: [%s]", err)
		}
		return nil, errorpb.ErrorInvalidToken("无效的token, err: [%s]", err)
	}
	if token == nil {
		return nil, errorpb.ErrorInvalidToken("无效的token")
	}
	claims, ok := token.Claims.(*CustomizedClaims)
	if !ok {
		return nil, errorpb.ErrorInvalidToken("无效的token")
	}
	if claims.UserID == "" {
		return nil, errorpb.ErrorUserNotFound("id为不存在")
	}
	return claims, nil
}

func GetUsernameFromContext(ctx context.Context) (string, error) {
	claims, ok := ctx.Value(ClaimsContextKey{}).(*CustomizedClaims)
	if !ok {
		return "", errorpb.ErrorInvalidToken("无效的token")
	}
	return claims.Audience[0], nil
}

func GetUserIDFromContext(ctx context.Context) (string, error) {
	claims, ok := ctx.Value(ClaimsContextKey{}).(*CustomizedClaims)
	if !ok {
		return "", errorpb.ErrorInvalidToken("无效的token")
	}
	return claims.UserID, nil
}
