package server

import (
	"context"
	"mime/multipart"
	netHttp "net/http"
	"path"
	"strings"

	"github.com/go-kratos/kratos/v2/transport/http"

	v1 "vistudio-infopage-backend/internal/errors/v1"
	"vistudio-infopage-backend/internal/pkg/middleware"
	"vistudio-infopage-backend/internal/pkg/utils"
	"vistudio-infopage-backend/internal/service"
)

var (
	images = []string{".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".svg"}
	videos = []string{".mp4", ".avi", ".mov", ".flv", ".wmv", ".mkv", ".rmvb", ".rm", ".mpeg", ".mpg", ".mpe", ".3gp",
		".dat", ".asf", ".asx", ".vob", ".m4v", ".f4v", ".f4p", ".f4a", ".f4b", ".webm"}
	whitelistFileTypes = []string{"image/png", "image/jpg", "image/gif", "image/jpeg", "application/pdf",
		"application/msword", "text/plain", "video/x-msvideo", "video/mp4"}
)

func FeedbackHandler(backend *service.BackendService) func(ctx http.Context) error {
	return func(ctx http.Context) error {
		req := &service.FeedbackRequest{}
		err := ctx.Request().ParseMultipartForm(20 << 26)
		if err != nil {
			return err
		}
		req.Types = ctx.Request().MultipartForm.Value["types"][0]
		req.Version = ctx.Request().MultipartForm.Value["version"][0]
		req.Title = ctx.Request().MultipartForm.Value["title"][0]
		req.Content = ctx.Request().MultipartForm.Value["content"][0]
		req.Connection = ctx.Request().MultipartForm.Value["connection"][0]
		req.FileParts = ctx.Request().MultipartForm.File["appendices"]
		req.Product = ctx.Request().MultipartForm.Value["product"][0]

		for _, filePart := range req.FileParts {
			if !isWhitelistFileTypes(filePart) {
				return v1.ErrorFiletypeForbidden("")
			}
		}
		http.SetOperation(ctx, middleware.OperationBackendCustomFeedback)
		h := ctx.Middleware(func(ctx context.Context, req interface{}) (interface{}, error) {
			return backend.FeedbackHandler(ctx, req.(*service.FeedbackRequest))
		})
		out, err := h(ctx, req)
		if err != nil {
			return err
		}

		reply, _ := out.(*service.FeedbackResponse)
		return ctx.Result(200, reply)
	}
}

func CreateVideoHandler(backend *service.BackendService) func(ctx http.Context) error {
	return func(ctx http.Context) error {
		req := &service.CreateVideoRequest{}
		err := ctx.Request().ParseMultipartForm(20 << 26)
		if err != nil {
			return err
		}
		req.Type = ctx.Request().MultipartForm.Value["type"][0]
		req.Title = ctx.Request().MultipartForm.Value["title"][0]
		req.Description = ctx.Request().MultipartForm.Value["description"][0]
		req.Tags = strings.Split(ctx.Request().MultipartForm.Value["tags"][0], ",")
		req.VideoFilePart = ctx.Request().MultipartForm.File["videoFilePart"][0]
		if !utils.SliceContainsAny(videos, strings.ToLower(path.Ext(req.VideoFilePart.Filename))) {
			return v1.ErrorIllegalParameter("视频文件格式错误，请输入[%s]其中的一种", videos)
		}
		req.FrontCoverFilePart = ctx.Request().MultipartForm.File["frontCoverFilePart"][0]
		if !utils.SliceContainsAny(images, strings.ToLower(path.Ext(req.FrontCoverFilePart.Filename))) {
			return v1.ErrorIllegalParameter("图片文件格式错误，请输入[%s]其中的一种", videos)
		}

		http.SetOperation(ctx, middleware.OperationBackendCustomCreateVideo)
		h := ctx.Middleware(func(ctx context.Context, req interface{}) (interface{}, error) {
			return backend.CreateVideoHandler(ctx, req.(*service.CreateVideoRequest))
		})
		out, err := h(ctx, req)
		if err != nil {
			return err
		}

		reply, _ := out.(*service.CreateVideoResponse)
		return ctx.Result(200, reply)
	}
}

func UpdateVideoHandler(backend *service.BackendService) func(ctx http.Context) error {
	return func(ctx http.Context) error {
		req := &service.UpdateVideoRequest{}
		err := ctx.Request().ParseMultipartForm(20 << 26)
		if err != nil {
			return err
		}
		req.ID = ctx.Request().MultipartForm.Value["id"][0]
		if err != nil {
			return err
		}
		req.Type = ctx.Request().MultipartForm.Value["type"][0]
		req.Title = ctx.Request().MultipartForm.Value["title"][0]
		req.Description = ctx.Request().MultipartForm.Value["description"][0]
		req.Tags = strings.Split(ctx.Request().MultipartForm.Value["tags"][0], ",")
		VideoFilePartParam := ctx.Request().MultipartForm.File["videoFilePart"]
		if len(VideoFilePartParam) != 0 {
			if !utils.SliceContainsAny(videos, strings.ToLower(path.Ext(VideoFilePartParam[0].Filename))) {
				return v1.ErrorIllegalParameter("视频文件格式错误，请输入[%s]其中的一种", videos)
			}
			req.VideoFilePart = VideoFilePartParam[0]
		}
		FrontCoverFilePartParam := ctx.Request().MultipartForm.File["frontCoverFilePart"]
		if len(FrontCoverFilePartParam) != 0 {
			if !utils.SliceContainsAny(images, strings.ToLower(path.Ext(FrontCoverFilePartParam[0].Filename))) {
				return v1.ErrorIllegalParameter("图片文件格式错误，请输入[%s]其中的一种", videos)
			}
			req.FrontCoverFilePart = FrontCoverFilePartParam[0]
		}

		http.SetOperation(ctx, middleware.OperationBackendCustomUpdateVideo)
		h := ctx.Middleware(func(ctx context.Context, req interface{}) (interface{}, error) {
			return backend.UpdateVideoHandler(ctx, req.(*service.UpdateVideoRequest))
		})
		out, err := h(ctx, req)
		if err != nil {
			return err
		}

		reply, _ := out.(*service.UpdateVideoResponse)
		return ctx.Result(200, reply)
	}
}

func isWhitelistFileTypes(file *multipart.FileHeader) bool {
	open, err := file.Open()
	if err != nil {
		return false
	}
	buffer := make([]byte, 512)
	_, err = open.Read(buffer)
	if err != nil {
		return false
	}
	mimeType := netHttp.DetectContentType(buffer)
	return utils.SliceContainsAny(whitelistFileTypes, mimeType)
}
