package server

import (
	http1 "net/http"
	"time"

	bbr_ratelimit "github.com/go-kratos/aegis/ratelimit"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-kratos/kratos/v2/middleware"
	"github.com/go-kratos/kratos/v2/middleware/logging"
	"github.com/go-kratos/kratos/v2/middleware/ratelimit"
	"github.com/go-kratos/kratos/v2/middleware/recovery"
	"github.com/go-kratos/kratos/v2/middleware/selector"
	"github.com/go-kratos/kratos/v2/middleware/validate"
	"github.com/go-kratos/kratos/v2/transport/http"
	"github.com/gorilla/handlers"
	"github.com/gorilla/mux"
	"golang.org/x/time/rate"

	v1 "vistudio-infopage-backend/api/backend/v1"
	"vistudio-infopage-backend/internal/conf"
	servermiddleware "vistudio-infopage-backend/internal/pkg/middleware"
	"vistudio-infopage-backend/internal/pkg/token"
	"vistudio-infopage-backend/internal/service"
)

type Limit struct {
	limit *rate.Limiter
}

func (l *Limit) Allow() (bbr_ratelimit.DoneFunc, error) {
	if l.limit.Allow() {
		return func(info bbr_ratelimit.DoneInfo) {
			if info.Err != nil {
				log.Error(info.Err)
			}
		}, nil
	}
	return nil, ratelimit.ErrLimitExceed
}

// NewHTTPServer new a HTTP server.
func NewHTTPServer(c *conf.Server, data *conf.Data, signer token.Signer,
	backend *service.BackendService, logger log.Logger) *http.Server {
	var opts = []http.ServerOption{
		http.Filter(handlers.CORS(handlers.AllowedOrigins([]string{"*"}))),
		http.Middleware(
			middleware.Chain(
				recovery.Recovery(),
				logging.Server(logger),
				selector.Server(
					ratelimit.Server(ratelimit.WithLimiter(&Limit{limit: rate.NewLimiter(rate.Every(1000*time.Millisecond), 10)})),
				).Match(servermiddleware.RateLimitMatch()).Build(),
				selector.Server(servermiddleware.Token(signer)).Match(servermiddleware.TokenIgnoreMatch()).Build(),
				validate.Validator(),
			),
		),
	}
	if c.Http.Network != "" {
		opts = append(opts, http.Network(c.Http.Network))
	}
	if c.Http.Addr != "" {
		opts = append(opts, http.Address(c.Http.Addr))
	}
	if c.Http.Timeout != nil {
		opts = append(opts, http.Timeout(c.Http.Timeout.AsDuration()))
	}
	srv := http.NewServer(opts...)
	v1.RegisterBackendHTTPServer(srv, backend)
	r := srv.Route("/")

	r.POST("/v1/feedback", FeedbackHandler(backend))
	r.POST("/v1/videos", CreateVideoHandler(backend))
	r.PUT("/v1/videos", UpdateVideoHandler(backend))

	router := mux.NewRouter()
	router.PathPrefix(data.Frontend.DownloadPath).
		Handler(http1.StripPrefix(
			data.Frontend.DownloadPath,
			http1.FileServer(http1.Dir(data.File.BasePath)),
		))
	srv.HandlePrefix(data.Frontend.DownloadPath, router)
	return srv
}
