package service

import (
	"context"

	v1 "vistudio-infopage-backend/api/backend/v1"
	"vistudio-infopage-backend/internal/biz"
)

// BackendService is a backend service.
type BackendService struct {
	v1.UnimplementedBackendServer

	feedback *biz.FeedbackUsecase
	uc       *biz.BackendUsecase
	user     *biz.UserUsecase
	video    *biz.VideoUsecase
}

// NewBackendService new a backend service.
func NewBackendService(uc *biz.BackendUsecase, feedback *biz.FeedbackUsecase,
	user *biz.UserUsecase, video *biz.VideoUsecase) *BackendService {
	return &BackendService{uc: uc, feedback: feedback, user: user, video: video}
}

// HealthCheck 健康检查
func (b *BackendService) HealthCheck(ctx context.Context, in *v1.HealthCheckRequest) (*v1.HealthCheckReply, error) {
	return &v1.HealthCheckReply{}, nil
}

// GetToken 内网登录获取token
func (b *BackendService) GetToken(ctx context.Context, in *v1.GetTokenRequest) (*v1.GetTokenReply, error) {
	user, err := b.user.InternalVerifyTicket(ctx, in.Ticket)
	if err != nil {
		return nil, err
	}
	return &v1.GetTokenReply{
		Token:    user.Token,
		UserID:   user.ID,
		Username: user.Name,
	}, nil
}

// GetOuterToken 外网登录获取token
func (b *BackendService) GetOuterToken(ctx context.Context, in *v1.GetOuterTokenRequest) (*v1.GetOuterTokenReply, error) {
	user, err := b.user.OuterVerifyTicket(ctx, in.Ticket)
	if err != nil {
		return nil, err
	}
	return &v1.GetOuterTokenReply{
		Token:    user.Token,
		UserID:   user.ID,
		Username: user.Name,
		Phone:    user.Phone,
		Mail:     user.Mail,
	}, nil
}

// ListVideosByType 按类型返回视频列表
func (b *BackendService) ListVideosByType(ctx context.Context, in *v1.ListVideosByTypeRequest) (*v1.ListVideosByTypeReply, error) {
	videos, err := b.video.ListByType(ctx, in.VideoType)
	if err != nil {
		return nil, err
	}
	results := make([]*v1.Video, 0, len(videos))
	for _, video := range videos {
		result := &v1.Video{
			Id:          video.ID,
			Type:        video.Type,
			Title:       video.Title,
			Description: video.Description,
			Tags:        video.Tags,
			UpdateTime:  video.UpdateTime.Local().Format("2006-01-02 15:04:05"),
		}
		if video.VideoRelativePath != nil {
			result.VideoPath = *video.VideoRelativePath
		}
		if video.FrontCoverRelativePath != nil {
			result.FrontCoverPath = *video.FrontCoverRelativePath
		}
		results = append(results, result)
	}
	return &v1.ListVideosByTypeReply{Videos: results}, nil
}

// DeleteVideo 删除视频
func (b *BackendService) DeleteVideo(ctx context.Context, in *v1.DeleteVideoRequest) (*v1.DeleteVideoReply, error) {
	return &v1.DeleteVideoReply{}, b.video.DeleteOne(ctx, in.VideoID)
}

// ListTagsByType 按类型返回视频标签列表
func (b *BackendService) ListTagsByType(ctx context.Context, in *v1.ListTagsByTypeRequest) (*v1.ListTagsByTypeReply, error) {
	tagsByType, err := b.video.ListTagsByType(ctx, in.VideoType)
	if err != nil {
		return nil, err
	}
	return &v1.ListTagsByTypeReply{Tags: tagsByType}, nil
}
