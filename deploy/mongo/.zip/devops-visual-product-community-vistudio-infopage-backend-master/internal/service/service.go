package service

import (
	"context"
	"mime/multipart"

	"github.com/google/wire"

	"vistudio-infopage-backend/internal/biz"
)

// ProviderSet is service providers.
var ProviderSet = wire.NewSet(NewBackendService)

type FeedbackRequest struct {
	Types      string
	Version    string
	Title      string
	Content    string
	Connection string
	Product    string
	FileParts  []*multipart.FileHeader
}

type FeedbackResponse struct{}

type CreateVideoRequest struct {
	Type               string                `json:"type,omitempty"`
	Title              string                `json:"title,omitempty"`
	Description        string                `json:"description,omitempty"`
	Tags               []string              `json:"tags,omitempty"`
	VideoFilePart      *multipart.FileHeader `json:"videoFilePart,omitempty"`
	FrontCoverFilePart *multipart.FileHeader `json:"frontCoverFilePart,omitempty"`
}

type CreateVideoResponse struct{}

type UpdateVideoRequest struct {
	ID                 string                `json:"id,omitempty"`
	Type               string                `json:"type,omitempty"`
	Title              string                `json:"title,omitempty"`
	Description        string                `json:"description,omitempty"`
	Tags               []string              `json:"tags,omitempty"`
	VideoFilePart      *multipart.FileHeader `json:"videoFilePart,omitempty"`
	FrontCoverFilePart *multipart.FileHeader `json:"frontCoverFilePart,omitempty"`
}

type UpdateVideoResponse struct{}

func (b *BackendService) FeedbackHandler(ctx context.Context, req *FeedbackRequest) (*FeedbackResponse, error) {
	feedback := &biz.Feedback{
		Types:      req.Types,
		Version:    req.Version,
		Title:      req.Title,
		Content:    req.Content,
		Connection: req.Connection,
		Product:    req.Product,
		FileParts:  req.FileParts,
	}
	return &FeedbackResponse{}, b.feedback.Feedback(ctx, feedback)
}

func (b *BackendService) CreateVideoHandler(ctx context.Context, req *CreateVideoRequest) (*CreateVideoResponse, error) {
	video := &biz.Video{
		ID:                 "",
		Type:               req.Type,
		Title:              req.Title,
		Description:        req.Description,
		Tags:               req.Tags,
		VideoFilePart:      req.VideoFilePart,
		FrontCoverFilePart: req.FrontCoverFilePart,
	}
	err := b.video.CreateVideo(ctx, video)
	if err != nil {
		return nil, err
	}
	return &CreateVideoResponse{}, nil
}

func (b *BackendService) UpdateVideoHandler(ctx context.Context, req *UpdateVideoRequest) (*UpdateVideoResponse, error) {
	video := &biz.Video{
		ID:                 req.ID,
		Type:               req.Type,
		Title:              req.Title,
		Description:        req.Description,
		Tags:               req.Tags,
		VideoFilePart:      req.VideoFilePart,
		FrontCoverFilePart: req.FrontCoverFilePart,
	}
	err := b.video.UpdateVideo(ctx, video)
	if err != nil {
		return nil, err
	}
	return &UpdateVideoResponse{}, nil
}
