//go:build tools
// +build tools

/******************************************************************************
* FILENAME:      tools.go
*
* AUTHORS:       Xie Rongwang START DATE: 周四 10月 13 2022
*
* LAST MODIFIED: 星期四, 十月 13th 2022, 上午11:34
*
* CONTACT:       rongwang.xie@smartmore.com
******************************************************************************/

package tools

import (
	_ "github.com/google/wire/cmd/wire"
	_ "github.com/grpc-ecosystem/grpc-gateway/v2/protoc-gen-openapiv2"
)
